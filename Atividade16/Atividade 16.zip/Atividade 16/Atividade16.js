function abrirCurso() {
    select = document.getElementById('cursoSelect');
    curso = select.value;

    confirmacao = confirm("Deseja abrir a janela com informações sobre este curso?");
    if (confirmacao) {
        let conteudo = "";
        switch (curso) {
            case "ads":
                window.open("https://fatecsorocaba.cps.sp.gov.br/cursos-fatec/analise-e-desenvolvimento-de-sistemas/","_blank", "width=600,height=300")
                break;
            case "logistica":
                window.open("https://fatecsorocaba.cps.sp.gov.br/cursos-fatec/logistica/","_blank", "width=600,height=300")
                break;
            case "fabMecanica":
                window.open("https://fatecsorocaba.cps.sp.gov.br/cursos-fatec/fabricacao-mecanica/","_blank", "width=600,height=300")
                break;
            case "projMecanico":
                window.open("https://fatecsorocaba.cps.sp.gov.br/cursos-fatec/projetos-mecanicos/","_blank", "width=600,height=300")
                break;
            case "gestao":
                window.open("https://fatecsorocaba.cps.sp.gov.br/cursos-fatec/gestao-da-qualidade/","_blank", "width=600,height=300")
                break;
        }
    }else {
        document.getElementById('cursoSelect').selectedIndex = 0;
    }
}