function CalcArea(){
    base = document.getElementById("base").value;
    altura = document.getElementById("altura").value;

    return ("Área = " + base*altura);
}


function Conta(){
    var nomeCorrentista;
    var banco;
    var numConta;
    var saldo;

    this.setNomeCorrentista = function(value){
        nomeCorrentista = value;
    }
    this.getNomeCorrentista = function(){
        return nomeCorrentista;
    }
    this.setBanco = function(value){
        banco = value;
    }
    this.getBanco= function(){
        return banco;
    }
    this.setNumeroConta = function(value){
        numConta = value;
   }
   this.getNumeroConta= function(){
       return numConta;
   }
       this.setSaldo = function(value){
        saldo = value;
    }
    this.getSaldo= function(){
        return saldo;
    }
}

function ContaCorrente(){
    var saldoEspecial;

    this.setSaldoEspecial = function(value){
        saldoEspecial = value;
    }
    this.getSaldoEspecial = function(){
        return saldoEspecial;
    }
}
    ContaCorrente.prototype = new Conta;

    var conta1 = new ContaCorrente;
    conta1.setNomeCorrentista("Pedro");
    conta1.setBanco("Itau");
    conta1.setNumeroConta("12345");
    conta1.setSaldo(1234);
    conta1.setSaldoEspecial(1000);

    alert("Conta Corrente\n"+
        "Nome Correntista: " + conta1.getNomeCorrentista() + "\n"+
        "Banco: " + conta1.getBanco() + "\n"+
        "Numero da Conta: " + conta1.getNumeroConta() + "\n"+
        "Saldo: " + conta1.getSaldo() + "\n"+
        "Saldo Especial: "+ conta1.getSaldoEspecial());



function ContaPoupanca(){
    var juros;
    var dataVencimento;

    this.setJuros = function(value){
        juros = Number(value)/100;
    }
    this.getJuros = function(){
        return juros*100;
    }
    this.setDataVencimento = function(value){
        dataVencimento = value;
    }
    this.getDataVencimento = function(){
        return dataVencimento;
    }

}
    ContaPoupanca.prototype = new Conta;

    var conta2 = new ContaPoupanca;
    conta2.setNomeCorrentista("João");
    conta2.setBanco("Itau");
    conta2.setNumeroConta("12346");
    conta2.setSaldo(2304);
    conta2.setJuros(16);
    conta2.setDataVencimento("24/12/25")

    alert("Conta Poupança\n" +
    "Nome Correntista: " + conta2.getNomeCorrentista() + "\n" +
    "Banco: " + conta2.getBanco() + "\n" +
    "Número da Conta: " + conta2.getNumeroConta() + "\n" +
    "Saldo: " + conta2.getSaldo() + "\n" +
    "Juros (%): " + conta2.getJuros() + "\n" +
    "Data de Vencimento: " + conta2.getDataVencimento());