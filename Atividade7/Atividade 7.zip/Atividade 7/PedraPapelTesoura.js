var opcaoUser;
var opcaoComp;
var resultado;
    // 0 = Pedra; 1 = Papel ; 2 = Tesoura


    opcaoUser = prompt("PEDRA, PAPEL OU TESOURA\nEscolha sua opção:\n  0 para pedra\n  1 para papel \n  2 para Tesoura");


opcaoComp = Math.floor(Math.random() * 3);

if (opcaoUser == opcaoComp){
    resultado = "Empate";
} else if (opcaoUser == 0){
    if(opcaoComp == 1){
        resultado = "Derrota";
    } else {
        resultado = "Vitoria";
    }
} else if (opcaoUser == 1){
    if (opcaoComp == 0) {
        resultado = "Vitoria";
    } else
        resultado ="Derrota";
} else if (opcaoUser == 2){
    if (opcaoComp == 0){
        resultado = "Derrota";
    } else
        resultado = "Vitoria";
} else {
    alert("Opção Inválida");
    opcaoComp = -1;
}


if (opcaoComp == 0 ){
    opcaoComp = "Pedra";
} else if (opcaoComp == 1){
    opcaoComp = "Papel";
} else if (opcaoComp == 2)
    opcaoComp = "Tesoura";

    if (opcaoUser == 0 ){
    opcaoUser = "Pedra";
} else if (opcaoUser == 1){
    opcaoUser = "Papel";
} else if (opcaoUser == 2)
    opcaoUser = "Tesoura";
if (opcaoComp != -1){
    alert("Sua escolha: " + opcaoUser
        +"\nEscolha do computador: " + opcaoComp
        +"\nResultado: " + resultado);
}