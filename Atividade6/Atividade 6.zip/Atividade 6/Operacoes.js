var numero1;
var numero2;
var soma;
var sub;
var mult;
var div;
var resto;

numero1 = prompt("Digite o primeiro número: ");
numero2 = prompt("Digite o segundo número: ");

numero1 = parseFloat(numero1);
numero2 = parseFloat(numero2);

soma = numero1+numero2;
sub = numero1-numero2;
mult = numero1*numero2;
div = numero1/numero2;
resto = numero1%numero2;

alert("Soma dos números: " + soma + "\nSubtração dos números: " + sub +
    "\nProduto dos números: " + mult + "\nDivisão dos números: " + div +
    "\nResto da divisão dos números: " + resto);

