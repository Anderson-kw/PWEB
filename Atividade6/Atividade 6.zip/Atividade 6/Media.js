var nome;
var nota1;
var nota2;
var nota3;
var nota4;
var media;

nome = prompt("Digite o seu nome: ");
nota1 = prompt("Digite sua primeira nota: ");
nota2 = prompt("Digite sua segunda nota: ");
nota3 = prompt("Digite a sua tercereira nota: ");
nota4 = prompt("Digite a sua quarta nota: ");

media = ((parseFloat(nota1) + parseFloat(nota2) + parseFloat(nota3) + parseFloat(nota4))/4);
alert(nome + ", sua média é: " + media);