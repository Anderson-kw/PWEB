//ótimo = 4; bom = 3; regular = 2; péssimo = 1;

var idade;
var sexo; 
var nota;

var somaIdades = 0;
var maisVelho = 0;
var maisNova = 200;
var qtddPessoas = 0;
var somaOtBom = 0;
var somaPessimo = 0;
var somaFeminino = 0;
var somaMasculino = 0;
var somaOutro = 0;

while ((idade = prompt("Digite sua idade: ")) >= 0){
    sexo = prompt("Digite seu sexo:\n Masculino = M\n Feminino = F\n Outro = O");
    nota = prompt("Digite a sua nota para o filme\n Ótimo = 4\n Bom = 3\n Regular = 2\n Péssimo = 1");

    somaIdades += Number(idade);

    if (idade > maisVelho){
        maisVelho = Number(idade);
    }

    if (idade < maisNova){
        maisNova = Number(idade);
    }

    qtddPessoas++;

    if (nota == 3 || nota == 4){
        somaOtBom++;
    } else if(nota == 1){
        somaPessimo++;
    }

    if (sexo == "M"){
        somaMasculino++;
    } else if (sexo =="F"){
        somaFeminino++;
    } else {
        somaOutro++;
    }
}

alert("Média das idades: " + (somaIdades/qtddPessoas).toFixed(2) +
    "\nIdade da pessoa mais velhas: " + maisVelho +
    "\nIdade da pessoa mais nova: " + maisNova +
    "\nQuantidade que responderam péssimo: " + somaPessimo +
    "\nPorcentagem que responderam Ótimo ou Bom: " + (somaOtBom/qtddPessoas).toFixed(2)*100 + " %" +
    "\nQuantidade de mulhers: " + somaFeminino +
    "\nQuantidade de Homens: " + somaMasculino +
    "\nOutros: "+somaOutro);