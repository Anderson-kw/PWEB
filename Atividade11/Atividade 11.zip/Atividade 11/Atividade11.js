function Funcionario1(){
    var matricula;
    var nome;
    var funcao;

    this.setMatricula = function(value){
        this.matricula = value;
    }
    this.getMatricula = function(){
        return this.matricula;
    }
    this.setNome = function(value){
        this.nome = value;
    }
    this.getNome = function(){
        return this.nome;
    }
    this.setFuncao = function(value){
        this.funcao = value;
    }
    this.getFuncao = function(){
        return this.funcao;
    }
    
}

var funcionario1 = new Funcionario1;
funcionario1.setFuncao("Limpar");
funcionario1.setMatricula("1324");
funcionario1.setNome("Lucas");
    
alert(`Matricula = ${funcionario1.matricula}  Nome = ${funcionario1.nome}  Função = ${funcionario1.funcao}`);


class Funcionario2{
    constructor(){
        this._matricula;
        this._nome;
        this._funcao;
    }
    setNome(value){
        this._nome = value;
    }
    setMatricula(value){
        this._matricula = value;
    }
    setFuncao(value){
        this._funcao = value;
    }
}

var funcionario2 = new Object();
funcionario2.funcao= "Lavar";
funcionario2.matricula = "1234";
funcionario2.nome = "Pedro";
    
alert(`Matricula = ${funcionario2.matricula}  Nome = ${funcionario2.nome}  Função = ${funcionario2.funcao}`);



function Funcionario3(matricula, nome, funcao){
    this.matricula = matricula;
    this.nome = nome;
    this.funcao = funcao;

    this.Exibir = function(){
        return (`Matricula = ${matricula}  Nome = ${nome}  Função = ${funcao}`)
    }
}

var funcionario3 = new Funcionario3("1342","Paula","Secar");
alert (funcionario3.Exibir());