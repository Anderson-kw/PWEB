function calcIMC(altura, peso) {
    var imc;

    imc = Number(peso) / (Number(altura) * Number(altura));

    if (imc < 18.5) {
        alert("Magreza, obesidade grau 0");
    } else if (imc >= 18.5 && imc < 24.9) {
        alert("Normal, obesidade grau 0");
    } else if (imc >= 24.9 && imc < 29.9) {
        alert("Sobrepeso, obesidade grau I");
    } else if (imc >= 29.9 && imc < 39.9) {
        alert("Obesidade, obesidade grau II");
    } else if (imc >= 39.9) {
        alert("Obesidade Grave, obesidade grau III");
    } else {
        alert("Valores inválidos");
    }
}

let altura = Number(prompt("Digite o valor da altura (em m):"));
let peso = Number(prompt("Digite o valor do peso (em kg):"));

calcIMC(altura,peso);
