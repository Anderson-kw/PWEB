function Maior(num1,num2,num3){
    return Math.max(num1,num2,num3);
}

function Crescente(num1,num2,num3){
    let numeros = [num1,num2,num3];

    return numeros.sort((a,b) => a - b);
}

function isPalindromo(texto){
    let frase = String(texto);

    frase = frase.toUpperCase();

    frase = frase.replaceAll(" ", "");

    let tamanho = frase.length;
        
    for (let i = 0; i < tamanho/2; i++){
        if (frase[i] !== frase[tamanho - 1 - i]){
            return ("Não é palindromo");

        }
    }

    return ("É Palindromo"); 
}

function tipoTriangulo(lado1, lado2,lado3){
    if (!(Math.abs(lado2 - lado3) < lado1 && lado1 < lado2 + lado3)){
        return ("Não é triângulo");
    }else if (!(Math.abs(lado1 - lado3) < lado2 && lado2 < lado1 + lado3)){
        return ("Não é triângulo");
    }else if (!(Math.abs(lado1 - lado2) < lado3 && lado3 < lado1 + lado2)){
        return ("Não é triângulo");
    }
    
    if (lado1 === lado2 && lado2 === lado3){
        return ("Triângulo equilátero");
    } else if (lado1 === lado2 || lado1 === lado3 || lado2 === lado3){
        return ("Triângulo isósceles");
    } else {
        return ("Triângulo escaleno");
    }        
}


let numero1 = Number(prompt("Primeiro numero: "));
let numero2 = Number(prompt("Segundo numero: "));
let numero3 = Number(prompt("Terceiro numero: "));
let palavra = prompt("Texto: ");

alert("Palindromo: " + isPalindromo(palavra));
alert("Maior:" + Maior(numero1,numero2,numero3));
alert("Ordem crescente:" + Crescente(numero1,numero2,numero3));
alert("TIpo de triângulo: " + tipoTriangulo(numero1,numero2,numero3))
