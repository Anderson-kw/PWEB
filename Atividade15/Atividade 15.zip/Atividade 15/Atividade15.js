function Validar(){
    nome = document.getElementById('nome');
    comentario = document.getElementById('comentario');
    radioSim = document.getElementById('Sim');
    radioNao = document.getElementById('Nao');

    if (nome.value.length < 10){
        alert("Nome não pode ter menos que 10 caracteres");
        return;
    }
    if (comentario.value.length < 20){
        alert("Comentário deve ter no mínimo 20 caracteres");
        return;
    }

    if (radioSim.checked){
        alert("Volte sempre à esta página!");
    } else if (radioNao.checked){
        alert("Que bom que você voltou a visitar esta página!");
    }
}

function Limpar(){
    nome = document.getElementById('nome')
    nome.value = "";
    comentario = document.getElementById('comentario')
    comentario.value = "";
    email = document.getElementById('email')
    email.value ="";
}